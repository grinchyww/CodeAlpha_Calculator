// Tape Calculator — CodeAlpha Frontend Task 2
// A desk adding machine: every step prints on a paper tape.
// Arithmetic uses a small state machine (no eval).

const $ = id => document.getElementById(id);
const exprEl = $('expression');
const resultEl = $('result');
const keysEl = $('keys');
const tapeEl = $('tape');
const linesEl = $('tapeLines');
const soundToggle = $('soundToggle');

const SYMBOLS = { '+': '+', '-': '−', '*': '×', '/': '÷' };
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

let current = '0';      // number being typed (string)
let previous = null;    // stored left operand (number)
let operator = null;    // pending operator
let resetNext = false;  // next digit starts a new number
let recalled = false;   // current value came from the tape
let lastExpr = '';      // small line on the display

/* ---------- Maths ---------- */
function compute(a, op, b) {
  switch (op) {
    case '+': return a + b;
    case '-': return a - b;
    case '*': return a * b;
    case '/': return b === 0 ? NaN : a / b;
    default: return b;
  }
}

function format(n) {
  if (!isFinite(n)) return 'Error';
  const r = parseFloat(n.toPrecision(12)); // 0.1 + 0.2 → 0.3
  return Math.abs(r) >= 1e12 || (r !== 0 && Math.abs(r) < 1e-9)
    ? r.toExponential(6)
    : String(r);
}

function tapeNumber(str) {
  const n = Number(str);
  if (Math.abs(n) >= 1e12) return str;
  return n.toLocaleString('en-US', { maximumFractionDigits: 10 });
}

/* ---------- Sound (generated, no files needed) ---------- */
let audioCtx = null;

function tick({ freq = 1800, dur = 0.035, gain = 0.2 } = {}) {
  if (!soundToggle.checked) return;
  try {
    audioCtx ||= new (window.AudioContext || window.webkitAudioContext)();
    const len = Math.max(1, Math.floor(audioCtx.sampleRate * dur));
    const buffer = audioCtx.createBuffer(1, len, audioCtx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3);

    const src = audioCtx.createBufferSource();
    src.buffer = buffer;
    const filter = audioCtx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = freq;
    filter.Q.value = 1.2;
    const amp = audioCtx.createGain();
    amp.gain.value = gain;
    src.connect(filter).connect(amp).connect(audioCtx.destination);
    src.start();
  } catch { /* audio not available — stay silent */ }
}

const keySound = () => tick({ freq: 1400, dur: 0.045, gain: 0.28 });

function printSound(chars) {
  const n = Math.min(chars, 10);
  for (let i = 0; i < n; i++) {
    setTimeout(() => tick({ freq: 3600, dur: 0.012, gain: 0.08 }), i * 24);
  }
}

/* ---------- Tape ---------- */
function scrollTape() {
  tapeEl.scrollTo({ top: tapeEl.scrollHeight, behavior: reduceMotion ? 'auto' : 'smooth' });
}

function print(value, sym = '', kind = '') {
  const li = document.createElement('li');
  li.className = `line ${kind}`.trim();

  const isNumber = value !== 'Error' && !isNaN(Number(value));
  if (isNumber && Number(value) < 0) li.classList.add('neg');

  const amt = document.createElement('span');
  amt.className = 'amt';
  amt.textContent = isNumber ? tapeNumber(value) : value;
  const symbol = document.createElement('span');
  symbol.className = 'sym';
  symbol.textContent = sym;
  li.append(amt, symbol);

  if (isNumber && kind !== 'clear') {
    li.dataset.value = String(Number(value));
    li.tabIndex = 0;
    li.title = 'Use this number';
  }

  linesEl.appendChild(li);
  scrollTape();
  printSound(String(value).length + 2);
}

function printRule() {
  const li = document.createElement('li');
  li.className = 'rule';
  li.setAttribute('aria-hidden', 'true');
  linesEl.appendChild(li);
}

/* ---------- Display ---------- */
function update() {
  resultEl.textContent = current;
  resultEl.classList.toggle('small', current.length > 10);

  if (operator !== null) {
    let text = `${format(previous)} ${SYMBOLS[operator]}`;
    if (!resetNext) {
      // Live preview while the second number is being typed
      const preview = compute(previous, operator, parseFloat(current));
      text += ` ${current} = ${format(preview)}`;
    }
    exprEl.textContent = text;
  } else {
    exprEl.textContent = lastExpr;
  }

  document.querySelectorAll('.key.op').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.op === operator && resetNext);
  });
}

/* ---------- Input ---------- */
function startFresh() {
  if (current === 'Error' || resetNext || recalled) {
    current = '0';
    resetNext = false;
    recalled = false;
    if (operator === null) lastExpr = '';
  }
}

function inputDigit(d) {
  startFresh();
  if (current.replace(/[-.]/g, '').length >= 15) return;
  if (current === '0') current = d;
  else if (current === '-0') current = '-' + d;
  else current += d;
}

function inputDecimal() {
  startFresh();
  if (!current.includes('.')) current += '.';
}

function resetState() {
  current = '0';
  previous = null;
  operator = null;
  resetNext = false;
  recalled = false;
  lastExpr = '';
}

function showError() {
  resetState();
  current = 'Error';
  resetNext = true;
  lastExpr = 'Cannot divide by zero';
  print('Error', 'E', 'err');
}

function setOperator(op) {
  if (current === 'Error') return;
  const value = parseFloat(current);

  if (operator !== null && !resetNext) {
    // Chained step: print the operand, then a subtotal (◇)
    print(current, SYMBOLS[operator]);
    const r = compute(previous, operator, value);
    if (!isFinite(r)) return showError();
    previous = r;
    current = format(r);
    print(current, '◇', 'sub');
  } else if (operator === null) {
    previous = value;
    print(current, '');
  }

  operator = op;
  resetNext = true;
  recalled = false;
  lastExpr = '';
}

function equals() {
  if (operator === null || current === 'Error') return;
  const b = resetNext ? previous : parseFloat(current);
  print(format(b), SYMBOLS[operator]);

  const r = compute(previous, operator, b);
  if (!isFinite(r)) return showError();

  lastExpr = `${format(previous)} ${SYMBOLS[operator]} ${format(b)} =`;
  current = format(r);
  previous = null;
  operator = null;
  resetNext = true;
  recalled = false;

  printRule();
  print(current, 'T', 'total');
}

function clearAll() {
  const last = linesEl.lastElementChild;
  if (last && !last.classList.contains('clear')) print('0', 'C', 'clear');
  resetState();
}

function deleteLast() {
  if (current === 'Error' || resetNext || recalled) {
    current = '0';
    resetNext = false;
    recalled = false;
    return;
  }
  current = current.slice(0, -1);
  if (current === '' || current === '-') current = '0';
}

function percent() {
  if (current === 'Error') return;
  current = format(parseFloat(current) / 100);
  print(current, '%');
}

function toggleSign() {
  if (current === 'Error') return;
  if (resetNext && operator !== null) { current = '0'; resetNext = false; }
  current = current.startsWith('-') ? current.slice(1) : '-' + current;
}

function recall(value) {
  if (current === 'Error') resetState();
  current = value;
  recalled = true;
  resetNext = false;
  if (operator === null) lastExpr = 'From the tape';
  // Move focus off the tape line so the next Enter means "equals"
  if (document.activeElement?.matches?.('li[data-value]')) document.activeElement.blur();
  keySound();
  update();
}

const actions = {
  clear: clearAll,
  delete: deleteLast,
  percent,
  sign: toggleSign,
  decimal: inputDecimal,
  equals,
};

/* ---------- Events ---------- */
keysEl.addEventListener('click', e => {
  const btn = e.target.closest('button');
  if (!btn) return;
  keySound();
  if (btn.dataset.num) inputDigit(btn.dataset.num);
  else if (btn.dataset.op) setOperator(btn.dataset.op);
  else if (btn.dataset.action) actions[btn.dataset.action]();
  update();
});

linesEl.addEventListener('click', e => {
  const li = e.target.closest('li[data-value]');
  if (li) recall(li.dataset.value);
});

function flash(selector) {
  const btn = document.querySelector(selector);
  if (!btn) return;
  btn.classList.add('pressed');
  setTimeout(() => btn.classList.remove('pressed'), 110);
}

document.addEventListener('keydown', e => {
  if (e.ctrlKey || e.metaKey || e.altKey) return;
  const k = e.key;

  // Enter on a focused tape line reuses that number
  if (k === 'Enter' && e.target.matches?.('li[data-value]')) {
    e.preventDefault();
    recall(e.target.dataset.value);
    return;
  }
  // Let focused buttons handle their own Enter/Space
  if ((k === 'Enter' || k === ' ') && e.target.tagName === 'BUTTON') return;

  let handled = true;
  if (/^[0-9]$/.test(k)) { inputDigit(k); flash(`[data-num="${k}"]`); }
  else if (k === '.' || k === ',') { inputDecimal(); flash('[data-action="decimal"]'); }
  else if (['+', '-', '*', '/'].includes(k)) { setOperator(k); flash(`[data-op="${k}"]`); }
  else if (k === 'x' || k === 'X') { setOperator('*'); flash('[data-op="*"]'); }
  else if (k === 'Enter' || k === '=') { equals(); flash('[data-action="equals"]'); }
  else if (k === 'Backspace') { deleteLast(); flash('[data-action="delete"]'); }
  else if (k === 'Escape' || k === 'Delete') { clearAll(); flash('[data-action="clear"]'); }
  else if (k === '%') { percent(); flash('[data-action="percent"]'); }
  else handled = false;

  if (handled) {
    e.preventDefault();
    keySound();
    update();
  }
});

// Tear off the tape
$('tearTape').addEventListener('click', () => {
  if (!linesEl.children.length) return;
  tick({ freq: 700, dur: 0.22, gain: 0.35 });
  tapeEl.classList.add('torn');
  setTimeout(() => {
    linesEl.innerHTML = '';
    tapeEl.classList.remove('torn');
  }, reduceMotion ? 0 : 460);
});

// Copy the tape as plain text
$('copyTape').addEventListener('click', async e => {
  const btn = e.currentTarget;
  const text = [...linesEl.children].map(li => {
    if (li.classList.contains('rule')) return '------------';
    const amt = li.querySelector('.amt').textContent;
    const sym = li.querySelector('.sym').textContent;
    return `${amt.padStart(14)} ${sym}`.trimEnd();
  }).join('\n');
  if (!text) return;

  const label = btn.textContent;
  try {
    await navigator.clipboard.writeText(text);
    btn.textContent = 'Copied';
  } catch {
    btn.textContent = 'Copy failed';
  }
  setTimeout(() => { btn.textContent = label; }, 1400);
});

update();
