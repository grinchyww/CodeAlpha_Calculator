# CodeAlpha_Calculator: Tape Calculator

A calculator built like an old desk adding machine. Every step of a sum prints on a paper tape that feeds out of the top of the machine. Task 2 of the CodeAlpha Frontend Development internship.

## Features
- Addition, subtraction, multiplication and division
- Display screen with a live preview of the result as you type
- Clear (AC), delete (⌫), percent (%) and sign toggle (±)
- Chained sums (`12 + 3 + 4`), with subtotals marked `◇` on the tape
- Safe maths without `eval()`, with floating-point cleanup (`0.1 + 0.2 = 0.3`)
- Clear message when dividing by zero

### Bonus
- **Paper tape:** each step prints with a typewriter animation. Totals are marked `T` and negative numbers print in red ink.
- **Reuse a number:** click any number on the tape to bring it back to the display.
- **Copy tape** copies the whole tape as text. **Tear off** clears it.
- **Keyboard support:** `0–9`, `.`, `+ − * /`, `Enter`, `Backspace`, `Esc`, `%`
- **Key sounds** are generated with the Web Audio API, so no sound files are needed. You can turn them off.
- Responsive layout, visible keyboard focus, and reduced-motion support

## Run locally
Open `index.html` in a browser. No build step is needed.

## Tech
HTML5, CSS3 (Grid, custom properties, keyframes), vanilla JavaScript, Web Audio API.
